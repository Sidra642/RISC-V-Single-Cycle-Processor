`timescale 1ns / 1ps

module tb_Register_File();

  // Testbench signals
  logic clk;
  logic reset;
  logic RegWrite;
  logic [4:0] Rs1, Rs2, Rd;
  logic [31:0] Write_data;
  logic [31:0] read_data1, read_data2;

  // Instantiate DUT
  Register_File uut (
    .clk(clk),
    .reset(reset),
    .RegWrite(RegWrite),
    .Rs1(Rs1),
    .Rs2(Rs2),
    .Rd(Rd),
    .Write_data(Write_data),
    .read_data1(read_data1),
    .read_data2(read_data2)
  );

  // Clock generation (10 ns period ? 100 MHz)
  initial clk = 0;
  always #5 clk = ~clk;

  // Stimulus
  initial begin
    // Reset all registers
    reset = 1;
    RegWrite = 0;
    Rs1 = 5'd0;
    Rs2 = 5'd0;
    Rd = 5'd0;
    Write_data = 32'h00000000;
    #12 reset = 0;

    // Write 0xAAAA_BBBB into register 5
    #10 RegWrite = 1; Rd = 5'd5; Write_data = 32'hAAAA_BBBB;
    #10 RegWrite = 0;

    // Write 0x1234_5678 into register 10
    #10 RegWrite = 1; Rd = 5'd10; Write_data = 32'h1234_5678;
    #10 RegWrite = 0;

    // Read from register 5 and 10
    #10 Rs1 = 5'd5; Rs2 = 5'd10;

    // Write into register 0 (should be ignored, x0 stays 0)
    #10 RegWrite = 1; Rd = 5'd0; Write_data = 32'hDEAD_BEEF;
    #10 RegWrite = 0;

    // Read again (check x0 and reg5)
    #10 Rs1 = 5'd0; Rs2 = 5'd5;

    // Apply reset again (clear all registers)
    #20 reset = 1;
    #10 reset = 0;

    // Read after reset
    #10 Rs1 = 5'd5; Rs2 = 5'd10;

    // End simulation
    #50 $finish;
  end

endmodule
