`timescale 1ns / 1ps

module tb_ImmGen();

  // Testbench signals
  logic [6:0]  opcode;
  logic [31:0] instruction;
  logic [31:0] ImmExt;

  // Instantiate DUT
  ImmGen uut (
    .opcode(opcode),
    .instruction(instruction),
    .ImmExt(ImmExt)
  );

  // Stimulus
  initial begin
    // Test I-type ADDI instruction
    opcode = 7'b0010011;
    instruction = 32'b111111111111_00000_000_00001_0010011; // imm = -1 (12-bit)
    #10;

    // Test I-type ANDI instruction
    instruction = 32'b000000000101_00010_111_00011_0010011; // imm = 5
    #10;

    // Test R-type instruction (no immediate)
    opcode = 7'b0110011;
    instruction = 32'b0000000_00001_00010_000_00011_0110011;
    #10;

    // Test default opcode (unsupported)
    opcode = 7'b0000000;
    instruction = 32'b0;
    #10;

    // End simulation
    #20 $finish;
  end

endmodule
