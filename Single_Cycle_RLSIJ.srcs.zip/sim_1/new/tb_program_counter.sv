`timescale 1ns / 1ps

module tb_program_counter();

  // Testbench signals
  logic clk;
  logic reset;
  logic [31:0] PC_in;
  logic [31:0] PC_out;

  // Instantiate the DUT
  program_counter uut (
    .clk(clk),
    .reset(reset),
    .PC_in(PC_in),
    .PC_out(PC_out)
  );

  // Clock Generation (10ns period -> 100 MHz)
  initial clk = 0;
  always #5 clk = ~clk;

  // Stimulus
  initial begin
    // Initial state
    reset = 1;
    PC_in = 32'h0000_0000;

    // Release reset
    #12 reset = 0;

    // Write first value
    #10 PC_in = 32'h0000_0004;

    // Write another value
    #20 PC_in = 32'h0000_0008;

    // Hold value (no change to PC_in)
    #20 PC_in = 32'h0000_000C;

    // Write again
    #20 PC_in = 32'h0000_0010;

    // Apply reset again
    #20 reset = 1;
    #10 reset = 0;

    // End simulation
    #50 $finish;
  end

endmodule
