`timescale 1ns / 1ps

module tb_Instruction_Memory();

  // Testbench signals
  logic clk;
  logic reset;
  logic [31:0] read_address;
  logic [31:0] instruction_out;

  // Instantiate DUT
  Instruction_Memory uut (
    .clk(clk),
    .reset(reset),
    .read_address(read_address),
    .instruction_out(instruction_out)
  );

  // Clock generation (10ns period ? 100 MHz)
  initial clk = 0;
  always #5 clk = ~clk;

  // Stimulus
  initial begin
    // Initial state with reset active
    reset = 1;
    read_address = 32'd0;
    #15 reset = 0;   // release reset

    // Fetch first instruction
    #10 read_address = 32'd4;

    // Fetch another instruction
    #10 read_address = 32'd8;

    // Fetch more instructions
    #10 read_address = 32'd12;
    #10 read_address = 32'd16;
    #10 read_address = 32'd20;
    #10 read_address = 32'd24;
    #10 read_address = 32'd28;

    // Jump to I-type instructions
    #10 read_address = 32'd44;
    #10 read_address = 32'd48;
    #10 read_address = 32'd52;
    #10 read_address = 32'd56;

    // Apply reset again to clear memory
    #20 reset = 1;
    #10 reset = 0;

    // Try reading after reset
    #10 read_address = 32'd4;

    // End simulation
    #50 $finish;
  end

endmodule
